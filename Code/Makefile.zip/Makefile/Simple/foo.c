#include <stdio.h>

void foo()
{
	printf("This is Foo()!\n");
}

